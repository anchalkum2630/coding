use student_management;
select * from student_register;



