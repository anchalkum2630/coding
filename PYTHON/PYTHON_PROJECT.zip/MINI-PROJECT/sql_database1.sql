/*
-- Query: select * from student_register
LIMIT 0, 1000

-- Date: 2024-04-23 10:15
*/
INSERT INTO `` (`f_name`,`l_name`,`course`,`subject`,`year`,`age`,`gender`,`birth`,`contact`,`email`) VALUES ('Shristy','Kumari','MCA','Operating system',2024,'sahibganj,jharkhand','female','2003-03-13','1010101010','shristy@gmail.com');
INSERT INTO `` (`f_name`,`l_name`,`course`,`subject`,`year`,`age`,`gender`,`birth`,`contact`,`email`) VALUES ('Roshni','Kumari','MCA','Computer networks,Dbms,UML,Software Engineering',2023,'Sahibganj,Jharkhand','Female','2005-06-17','9999999999','roshni@gmail.com');
